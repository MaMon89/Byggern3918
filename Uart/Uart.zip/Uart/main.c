/*
 * Uart.c
 *
 * Created: 04.09.2018 09.43.47
 * Author : Grendar
 */ 


#define F_CPU 4912500 /*4912500UL*/
#define BAUD 9600
#define UBRREG F_CPU/16/BAUD-1

#include <avr/io.h>
#include <util/delay.h>

#include "UART.h"



void main(void)
{
	DDRA = 0x01;
	unsigned int a = 0;
	UART_Init(UBRREG);
	
	while(1){
		a = a + 1;
		UART_TX(a);
		//UART_RX();
		_delay_ms(100);
	//	printf("Dette er %c. \r\n", UART_RX());

		
		PORTA |= (1 << 0);
		_delay_ms(500);
		PORTA &= ~ (1 << 0);
		_delay_ms(500);
		
	}
}